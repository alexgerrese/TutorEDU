import React, { Component } from 'react';
import './styles.css';

class MovieDetail extends Component {
  render() {
    return (
      <div className="movie-description">
        <img  src={ this.props.poster }
              alt={ this.props.name }
              className="movie-detail-image"/>
            <h1 className="movie-detail-title">{ this.props.name + " (" + this.props.date + ")" }</h1>
        <div className="movie-description-box">
          <h3 className="movie-detail-description">{ this.props.description }</h3>
        </div>
      </div>
    )
  }
}

export default MovieDetail;
