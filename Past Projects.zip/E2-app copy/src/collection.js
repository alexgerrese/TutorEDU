import React, { Component } from 'react';
import Movie from './movie';
import MovieDetail from './MovieDetail';
// testing for git
class Collection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isShow: true,
      movies: [],
      selectedMovie: "none",
      selectedMovieDescription: "",
      selectedMovieDate: "",
      selectedMoviePoster: ""
    };
    this.handleClick = this.handleClick.bind(this)
    this.goBack = this.goBack.bind(this)
  }

  handleClick(e) {
    this.setState({
      selectedMovie: e.name,
      selectedMovieDescription: e.description,
      selectedMovieDate: e.date,
      selectedMoviePoster: e.poster
    });
  }

  goBack() {
    this.setState({
      selectedMovie: "none"
    });
  }

  async componentDidMount() {
    const response = await fetch("https://api.themoviedb.org/3/movie/top_rated?api_key=e83c646d73f735bd6ce57c5238782f4c&language=en-US&page=1");
    const json = await response.json();
    this.setState({ movies: json.results });
  }

  render() {
    if(this.state.selectedMovie === "none") {
      return  (
        <div className="collection">
          {this.state.movies.map((movie,k) => (
            <Movie  key={k}
                    poster={ "https://image.tmdb.org/t/p/w500" + movie.poster_path } name={ movie.title }
                    date={ movie.release_date }
                    description={ movie.overview }
                    onPress={ this.handleClick }/>
          ))}
          </div>
        )
    }
    else {
      return (
        <div className="collection">
            <button onClick={this.goBack}>Back</button>
            <MovieDetail  name={this.state.selectedMovie}
                          description={ this.state.selectedMovieDescription }
                          date={this.state.selectedMovieDate}
                          poster={this.state.selectedMoviePoster}
                          />
          </div>
      )
      }
    }
  }

export default Collection;
