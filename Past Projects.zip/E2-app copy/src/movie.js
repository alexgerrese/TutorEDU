import React, { Component } from 'react';
import './styles.css';

class Movie extends Component {

  clicked = () => {
    this.props.onPress(this.props);
  }

  render() {
    return (
      <div className="movie-card">
        <img  src={ this.props.poster }
              alt={ this.props.name }
              className="movie-image"
              onClick={ this.clicked }/>
      </div>
    )
  }
}

export default Movie;
