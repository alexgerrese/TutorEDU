import React, { Component } from 'react';

class MovieDetail extends Component {
  render() {
    return <Button color="blue" />
  }
}

export default MovieDetail;
